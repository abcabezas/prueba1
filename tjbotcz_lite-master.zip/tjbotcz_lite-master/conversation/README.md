# TJBotCZ conversation sample
Here you will find conversation file (workspace-tjbotcz_lite.json), that needs to be imported to Watson Assisstant service (see manuals for more information). 

The conversation works with LITE version of the service that is offered for free. 
